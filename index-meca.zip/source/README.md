# A-guide-to-temporal-complexity-for-fMRI-scientists
