def main():
    print("Hello from quartomanuscript!")


if __name__ == "__main__":
    main()
